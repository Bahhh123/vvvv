export default {
    uuid: { type: String, required: true },
    token: { type: String, required: true },
    user_id: { type: String, required: true },
    date: { type: Number, default: 0 },
}